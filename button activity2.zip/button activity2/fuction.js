function toopenthefile() {
  document.getElementById('moreContent').style.display = 'block';
}

function hide() {
  document.getElementById('moreContent').style.display = 'none';
}

function change() {
  const image = document.querySelector('#moreContent img');
  image.src = 'c:\Users\erlee\OneDrive\Documents\Downloads\386172404_632973122363352_7733046868552737324_n.jpg';
}
  function back() {
    const image = document.querySelector('#moreContent img');
    image.src = 'c:\Users\erlee\OneDrive\Documents\Downloads\OIF.jpg';
  const paragraph = document.querySelector('#moreContent p');

  paragraph.textContent = 'Michelle Dee. Actress: Because I Love You. Michelle Dee is known for Because I Love You (2019), Agimat ng agila (2021) and Mga lihim ni Urduja (2023).';
}
